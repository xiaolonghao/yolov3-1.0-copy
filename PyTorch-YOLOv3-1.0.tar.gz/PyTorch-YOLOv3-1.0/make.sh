conda env create -f enviroment.yaml;
pip install -r requirements.txt;
cd PyTorch-YOLOv3-1.0;
cd weights;
bash download_weights.sh;
cd ../data;
bash get_coco_dataset.sh;
python train.py
